This folder contains the low-resource data splits used for our experiments for 1, 5, and 25 SPIs settings for SNIPS and TOP v2. Each setting has three randomly sampled splits from the original training data. We share this for reproducibility. All examples are already processed into the seq2seq-ptr format and tokenized by the roberta tokenizer.

The original TOPv2 and SNIPS datasets can be downloaded online at the following links.

TOP v2 - https://fb.me/TOPv2Dataset
SNIPS - https://github.com/sonos/nlu-benchmark
Wikiwiki - https://github.com/amazon-research/wikiwiki-dataset/